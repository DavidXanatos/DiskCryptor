#ifndef _BOOT_PASS_
#define _BOOT_PASS_

void dc_get_boot_pass();

#endif