﻿---- en ----
Bootloader completely rewritten now, this release includes the binary loader from DiskCryptor 1.0.732.111

---- ru ----
Загрузчик сейчас полностью переписывается, эта версия содержит бинарник загрузчика из DiskCryptor 1.0.732.111
