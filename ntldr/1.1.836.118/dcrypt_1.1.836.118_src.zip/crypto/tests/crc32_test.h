﻿#pragma once

int test_crc32();