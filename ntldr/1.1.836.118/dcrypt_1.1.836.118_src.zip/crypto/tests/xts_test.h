﻿#pragma once

int test_xts_mode();