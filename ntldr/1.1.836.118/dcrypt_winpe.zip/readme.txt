﻿BartPE (http://www.nu2.nu/pebuilder/), Windows XP LiveCD
Win7PE_SE (http://w7pese.cwcodes.net/), Windows 7 LiveCD