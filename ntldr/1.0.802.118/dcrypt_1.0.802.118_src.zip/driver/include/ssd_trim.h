#ifndef _SSD_TRIM_H_
#define _SSD_TRIM_H_

void dc_trim_free_space(dev_hook *hook);

#endif