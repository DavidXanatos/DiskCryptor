#ifndef _MINIFILTER_H_
#define _MINIFILTER_H_

void mf_init(PDRIVER_OBJECT drv_obj);

#endif