#ifndef _DISK_INFO_H_
#define _DISK_INFO_H_

NTSTATUS dc_fill_device_info(dev_hook *hook);

#endif