#ifndef _PRCOPTIONS_
#define _PRCOPTIONS_

int _dlg_options(
		HWND hwnd
	);

#endif