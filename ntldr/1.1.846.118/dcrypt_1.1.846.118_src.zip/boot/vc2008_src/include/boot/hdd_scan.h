#ifndef _HDD_SCAN_H_
#define _HDD_SCAN_H_

int dc_find_hdds();
int dc_find_partitions();

#endif