﻿#pragma once

int test_sha512_hmac();