#ifndef _BENCHMARK_
#define _BENCHMARK_

int dc_k_benchmark(int cipher, dc_bench_info *info);

#endif