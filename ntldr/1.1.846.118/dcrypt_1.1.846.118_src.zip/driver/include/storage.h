#ifndef _STORAGE_H_
#define _STORAGE_H_

int  dc_create_storage(dev_hook *hook, u64 *storage);
void dc_delete_storage(dev_hook *hook);

#endif