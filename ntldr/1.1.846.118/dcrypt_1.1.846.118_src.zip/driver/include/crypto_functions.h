﻿#ifndef _CRYPTO_FUNCTIONS_H_
#define _CRYPTO_FUNCTIONS_H_

void dc_init_encryption();
void dc_free_encryption();

#endif
