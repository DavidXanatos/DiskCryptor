#ifndef _AUTORUN_
#define _AUTORUN_

int autorun_set(int run);
int on_app_start(wchar_t *cmd_line);

#endif