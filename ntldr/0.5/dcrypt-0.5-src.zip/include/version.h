#ifndef _VERSION_
#define _VERSION_

#define DC_MAJOR_VER   0
#define DC_MINOR_VER   5
#define DC_DRIVER_VER  325  /* driver version */
#define DC_BOOT_VER    84   /* bootloader version */
#define DC_FILE_VER    L"0.5.325.84"
#define DC_PRODUCT_VER L"0.5"

#endif
