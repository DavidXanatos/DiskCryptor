/*
    *
    * DiskCryptor - open source partition encryption tool
    * Copyright (c) 2007-2008 
    * ntldr <ntldr@diskcryptor.net> PGP key ID - 0xC48251EB4F8E4E6E
    *

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/

#include <ntifs.h>
#include "defines.h"
#include "dump_hook.h"
#include "driver.h"
#include "crypto.h"
#include "misc.h"
#include "mount.h"
#include "mem_lock.h"
#include "debug.h"

typedef struct _dump_context
{
    PDUMP_DRIVER_OPEN          OpenRoutine;
	PDUMP_DRIVER_WRITE         WriteRoutine;
	PDUMP_DRIVER_WRITE_PENDING WritePendingRoutine;
	PDUMP_DRIVER_FINISH        FinishRoutine;
	dev_hook                  *hook;
	int                        pg_init;
	int                        pg_pending;
	void                      *a_data;

} dump_context;

typedef NTSTATUS (*dump_entry)(
      IN PVOID               unk, 
	  IN PDUMP_STACK_CONTEXT stack
	  );

static PLIST_ENTRY  ps_loaded_mod_list;
static PVOID        dump_mem;
static PMDL         dump_mdl;
static PVOID        dump_imgbase;
static FAST_MUTEX   dump_sync;
static dump_entry   dump_old_entry;
static dump_context dump_ctx[2];

#define DUMP_MEM_SIZE 4096 * 16

#ifdef _M_IX86 /* x86 jumper code */
 static u8 jmp_code[] = 
	 "\x8B\x44\x24\x08\x8B\x4C\x24\x04\x50\x51\x68\x00"
	 "\x00\x00\x00\xBA\x00\x00\x00\x00\xFF\xD2\xC2\x08\x00";
 #define DEST_OFF 16  /* destination address offset in code  */
 #define PARM_OFF 11  /* additional parameter offset in code */
#else         /* x64 jumper code */
 static u8 jmp_code[] = 
	 "\x4C\x8B\xC2\x48\x8B\xD1\x48\xB8\x00\x00\x00\x00\x00\x00"
	 "\x00\x00\x48\xB9\x00\x00\x00\x00\x00\x00\x00\x00\x48\xFF\xE0";
 #define DEST_OFF 8   /* destination address offset in code  */
 #define PARM_OFF 18  /* additional parameter offset in code */
#endif                                                            

typedef struct _entry_hook {
	dump_entry old_entry;
	u8         code[50];

} entry_hook;


static
int img_cmp(
	IN PUNICODE_STRING img_name,
	IN PWCHAR          cmp_name
	)
{
	u16 size = (u16)(wcslen(cmp_name) * 2);

	return (img_name->Length >= size) &&
		   (memcmp(img_name->Buffer, cmp_name, size) == 0);
}

static
PLDR_DATA_TABLE_ENTRY
  find_image(void *img_base)
{
	PLIST_ENTRY           entry;
	PLDR_DATA_TABLE_ENTRY table;
	PLDR_DATA_TABLE_ENTRY found = NULL;

	entry = ps_loaded_mod_list->Flink;

	while (entry != ps_loaded_mod_list)
	{
		table = CONTAINING_RECORD(entry, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		entry = entry->Flink;

		if (table->DllBase == img_base) {
			found = table; break;
		}
	}

	return found;
}


static
NTSTATUS 
  dump_mem_write(dump_context *dump, u32 size, u64 offset)
{
	NTSTATUS status;

	MmInitializeMdl(dump_mdl, dump_mem, size);

	dump_mdl->MappedSystemVa = dump_mem;
	dump_mdl->MdlFlags       = MDL_SOURCE_IS_NONPAGED_POOL;

	if (dump->pg_init != 0) 
	{
		if (dump->pg_pending != 0) 
		{
			status = dump->WritePendingRoutine(
				IO_DUMP_WRITE_FINISH, NULL, NULL, dump->a_data);			

			if (NT_SUCCESS(status) != FALSE) {
				dump->pg_pending = 0;
			}
		}

		status = dump->WritePendingRoutine(
			IO_DUMP_WRITE_START, pv(&offset), dump_mdl, dump->a_data);

		if (NT_SUCCESS(status) != FALSE) {
			dump->pg_pending = 1;
		}
	} else {
		status = dump->WriteRoutine(pv(&offset), dump_mdl);
		zeroauto(dump_mem, DUMP_MEM_SIZE);
	}

	return status;
}

static
NTSTATUS 
  dump_disk_write(
      dump_context *dump, void *buff, u32 size, u64 offset
	  )
{
	fastcpy(dump_mem, buff, size);

	return dump_mem_write(dump, size, offset);
}

static
NTSTATUS 
  dump_single_write(
      dump_context *dump, void *buff, u32 size, u64 offset, dc_key *key
	  )
{
	dc_cipher_encrypt(
		buff, dump_mem, size, offset, key);

	return dump_mem_write(dump, size, offset);
}

static
NTSTATUS 
  dump_encrypted_write(
      dump_context *dump, u8 *buff, u32 size, u64 offset
	  )
{
	dev_hook *hook = dump->hook;
	NTSTATUS  status;
	u64       o1, o2, o3;
	u32       s1, s2, s3;
	u8       *p2, *p3;
	
	s1 = intersect(&o1, offset, size, 0, DC_AREA_SIZE);
	
	if (hook->flags & F_SYNC) {
		s2 = intersect(&o2, offset, size, DC_AREA_SIZE, (hook->tmp_size - DC_AREA_SIZE));
		s3 = intersect(&o3, offset, size, hook->tmp_size, hook->dsk_size);		
	} else {
		s2 = intersect(&o2, offset, size, DC_AREA_SIZE, hook->dsk_size);
		s3 = 0;
	}
	p2 = buff + s1;
	p3 = p2 + s2;

	/*
	   normal mode:
	    o1:s1 - redirected part
		o2:s2 - encrypted part
		o3:s3 - unencrypted part
	   reencrypt mode:
	   o1:s1 - redirected part
	   o2:s2 - key_1 encrypted part
	   o3:s3 - key_2 encrypted part
	*/

	do
	{
		if (s1 != 0)
		{
			status = dump_encrypted_write(
				dump, buff, s1, hook->stor_off + o1);

			if (NT_SUCCESS(status) == FALSE) {
				break;
			}
		}

		if (s2 != 0)
		{
			status = dump_single_write(
				dump, p2, s2, o2, &hook->dsk_key);

			if (NT_SUCCESS(status) == FALSE) {
				break;
			}
		}

		if (s3 != 0)
		{
			if (hook->flags & F_REENCRYPT) {
				status = dump_single_write(dump, p3, s3, o3, hook->tmp_key);
			} else {
				status = dump_disk_write(dump, p3, s3, o3);
			}
		}
	} while (0);

	return status;
}

static
NTSTATUS
   dump_write_routine(
       dump_context *dump, u64 offset, PMDL mdl, void *a_data
	   )
{
	void    *buff = mdl->MappedSystemVa;
	u32      size = mdl->ByteCount;
	NTSTATUS status;

	if (size > DUMP_MEM_SIZE) {
		KeBugCheck(STATUS_BUFFER_OVERFLOW);
	}

	dump->a_data = a_data;

	if (dump->hook->flags & F_ENABLED) {
		status = dump_encrypted_write(dump, buff, size, offset);
	} else {
		status = dump_disk_write(dump, buff, size, offset);
	}

	return status;
}

static
NTSTATUS
   dump_crash_write(
       PLARGE_INTEGER disk_offset, PMDL mdl
	   )
{
	return dump_write_routine(		
		&dump_ctx[0], disk_offset->QuadPart, mdl, NULL);
}

static
NTSTATUS
   dump_hiber_write(
       PLARGE_INTEGER disk_offset, PMDL mdl
	   )
{
	return dump_write_routine(		
		&dump_ctx[1], disk_offset->QuadPart, mdl, NULL);
}

static
NTSTATUS
   dump_crash_write_pend(
       IN LONG           action,
	   IN PLARGE_INTEGER disk_offset,
	   IN PMDL           mdl,
	   IN PVOID          local_data
	   )
{
	dump_context *dump = &dump_ctx[0];
	NTSTATUS      status;
	
	if (action == IO_DUMP_WRITE_START) {
		status = dump_write_routine(dump, disk_offset->QuadPart, mdl, local_data);	
	} else
	{
		status = dump->WritePendingRoutine(action, disk_offset, dump_mdl, local_data);

		if (NT_SUCCESS(status) != FALSE)
		{
			dump->pg_init    |=  (action == IO_DUMP_WRITE_INIT);
			dump->pg_pending &= ~(action == IO_DUMP_WRITE_FINISH);
		}	
	}

	return status;
}

static
NTSTATUS
   dump_hiber_write_pend(
       IN LONG           action,
	   IN PLARGE_INTEGER disk_offset,
	   IN PMDL           mdl,
	   IN PVOID          local_data
	   )
{
	dump_context *dump = &dump_ctx[1];
	NTSTATUS      status;
	
	if (action == IO_DUMP_WRITE_START) {
		status = dump_write_routine(dump, disk_offset->QuadPart, mdl, local_data);	
	} else
	{
		status = dump->WritePendingRoutine(action, disk_offset, dump_mdl, local_data);

		if (NT_SUCCESS(status) != FALSE)
		{
			dump->pg_init    |=  (action == IO_DUMP_WRITE_INIT);
			dump->pg_pending &= ~(action == IO_DUMP_WRITE_FINISH);
		}	
	}

	return status;
}

static void dump_crash_finish(void)
{
	if (dump_ctx[0].FinishRoutine != NULL) {
		dump_ctx[0].FinishRoutine();
	}

	dc_clean_pass_cache();
	dc_clean_locked_mem(NULL);
	dc_clean_keys();

	zeroauto(dump_mem, DUMP_MEM_SIZE);
}

static void dump_hiber_finish(void)
{
	if (dump_ctx[1].FinishRoutine != NULL) {
		dump_ctx[1].FinishRoutine();
	}

	dc_clean_pass_cache();
	dc_clean_locked_mem(NULL);
	dc_clean_keys();

	dump_ctx[1].pg_init    = 0;
	dump_ctx[1].pg_pending = 0;
	dump_ctx[1].a_data     = NULL;

	zeroauto(dump_mem, DUMP_MEM_SIZE);	
}

int is_dump_crypt() 
{
	return (dump_ctx[0].hook != NULL) && 
		   (dump_ctx[0].hook->flags & F_ENABLED);
}

int is_hiber_crypt() 
{
	return (dump_ctx[1].hook != NULL) && 
		   (dump_ctx[1].hook->flags & F_ENABLED);
}

static
BOOLEAN
   dump_crash_open(
       IN LARGE_INTEGER part_offs
	   )
{
	int allow = (dc_dump_disable == 0);

	/* prevent dumping if memory contain sensitive data */
	if (is_dump_crypt() == 0) 
	{
		if (dc_num_mount() == 0) {
			/* clear pass cache to prevent leaks */
			dc_clean_pass_cache(); 
		} else {
			allow = 0;
		}
	}

	if ( (allow != 0) && (dump_ctx[0].OpenRoutine) ) {
		return dump_ctx[0].OpenRoutine(part_offs);
	} else {
		return FALSE;
	}
}

static
NTSTATUS
  dump_driver_entry(
      IN entry_hook         *ehook,
      IN PVOID               unk, 
	  IN PDUMP_STACK_CONTEXT stack
	  )
{
	PDUMP_INITIALIZATION_CONTEXT init;
	NTSTATUS                     status = STATUS_UNSUCCESSFUL;
	int                          idx;
	
	if (ehook->old_entry) {
		status = ehook->old_entry(unk, stack);
		ehook->old_entry = NULL;
	}

	if (NT_SUCCESS(status) && (unk == NULL) && (stack != NULL) )
	{
		init = &stack->Init; idx = 0;

		if (stack->UsageType == DeviceUsageTypeHibernation) {
			idx++;
		} else {
			if (stack->UsageType != DeviceUsageTypeDumpFile) {
				idx += (init->CrashDump == FALSE);
			}
		}

		dump_ctx[idx].OpenRoutine         = init->OpenRoutine;
		dump_ctx[idx].WriteRoutine        = init->WriteRoutine;	
		dump_ctx[idx].WritePendingRoutine = init->WritePendingRoutine;
		dump_ctx[idx].FinishRoutine       = init->FinishRoutine;
		
		if (idx == 0) 
		{
			if (init->WriteRoutine) {
				init->WriteRoutine = dump_crash_write;
			}
			if (init->WritePendingRoutine) {
				init->WritePendingRoutine = dump_crash_write_pend;
			}
			init->OpenRoutine   = dump_crash_open;
			init->FinishRoutine = dump_crash_finish;
		} else
		{
			if (init->WriteRoutine) {
				init->WriteRoutine = dump_hiber_write;
			}
			if (init->WritePendingRoutine) {
				init->WritePendingRoutine = dump_hiber_write_pend;
			}
			init->FinishRoutine = dump_hiber_finish;
		}
	}

	return status;
}

static void hook_dump_entry()
{
	PLDR_DATA_TABLE_ENTRY table;
	entry_hook           *ehook;

	ExAcquireFastMutex(&dump_sync);

	if ( (dump_imgbase != NULL) && 
		 (table = find_image(dump_imgbase)) )
	{
		if ( (table->BaseDllName.Buffer != NULL) && 
			 (table->EntryPoint != NULL) )
		{
			if (img_cmp(&table->BaseDllName, L"dump_") || 
				img_cmp(&table->BaseDllName, L"hiber_") ) 
			{
				if (ehook = mem_alloc(sizeof(entry_hook)))
				{
					autocpy(ehook->code, jmp_code, sizeof(jmp_code));
					ppv(ehook->code + DEST_OFF)[0] = dump_driver_entry;
					ppv(ehook->code + PARM_OFF)[0] = ehook;
					ehook->old_entry  = table->EntryPoint;
					table->EntryPoint = pv(ehook->code);					
				}
			}
		}

		dump_imgbase = NULL;
	}

	ExReleaseFastMutex(&dump_sync);
}

static
void load_img_routine(
	     IN PUNICODE_STRING img_name,
		 IN HANDLE          pid,
		 IN PIMAGE_INFO     img_info
		 )
{
	if (img_info->SystemModeImage) 
	{
		if (dc_os_type == OS_WIN2K) {
			hook_dump_entry();
			dump_imgbase = img_info->ImageBase;
		} else {
			dump_imgbase = img_info->ImageBase;
			hook_dump_entry();
		}
	}
}



void dump_usage_notify(
	     IN dev_hook                      *hook,
		 IN DEVICE_USAGE_NOTIFICATION_TYPE type
		 )
{
	if (type == DeviceUsageTypeDumpFile) {
		dump_ctx[0].hook = hook;
	}

	if (type == DeviceUsageTypeHibernation) {
		dump_ctx[1].hook = hook;
	}

	if (dc_os_type == OS_WIN2K) {
		hook_dump_entry();
	}
}

int dump_hook_init()
{
	PLDR_DATA_TABLE_ENTRY table;
	PHYSICAL_ADDRESS      high_addr;
	PLIST_ENTRY           entry;
	NTSTATUS              status;
	int                   resl = 0;

	ExInitializeFastMutex(&dump_sync);

	ExAcquireFastMutex(&dump_sync);

	/* find PsLoadedModuleListHead */
	entry = ((PLIST_ENTRY)(dc_driver->DriverSection))->Flink;

	while (entry != dc_driver->DriverSection)
	{
		table = CONTAINING_RECORD(entry, LDR_DATA_TABLE_ENTRY, InLoadOrderLinks);
		entry = entry->Flink;

		if ( (table->BaseDllName.Length == 0x18) && 
			 (p32(table->BaseDllName.Buffer)[0] == 0x0074006E) )
		{
			ps_loaded_mod_list = pv(table->InLoadOrderLinks.Blink);
			break;
		}
	}

	ExReleaseFastMutex(&dump_sync);

	do
	{
		if (ps_loaded_mod_list == NULL) {
			break;
		}

		status = PsSetLoadImageNotifyRoutine(load_img_routine);

		if (NT_SUCCESS(status) == FALSE) {
			break;
		}

		high_addr.HighPart = 0;
		high_addr.LowPart  = 0xFFFFFFFF;

		dump_mem = MmAllocateContiguousMemory(DUMP_MEM_SIZE, high_addr);

		if (dump_mem == NULL) {
			break;
		}

		dump_mdl = IoAllocateMdl(
			dump_mem, DUMP_MEM_SIZE, FALSE, FALSE, NULL); 

		if (dump_mdl == NULL) {
			break;
		}

		zeroauto(dump_mem, DUMP_MEM_SIZE);
		MmBuildMdlForNonPagedPool(dump_mdl); 
		resl = 1;
	} while (0);

	if (resl == 0) 
	{
		if (dump_mdl != NULL) {
			IoFreeMdl(dump_mdl);
		}

		if (dump_mem != NULL) {
			MmFreeContiguousMemory(dump_mem);
		}
	}

	return resl;	
}
