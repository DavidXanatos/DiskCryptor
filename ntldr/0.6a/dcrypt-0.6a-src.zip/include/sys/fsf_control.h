#ifndef _FSF_CONTROL_H_
#define _FSF_CONTROL_H_

void dc_fsf_connect(int allow_load);
void dc_fsf_set_flags(wchar_t *dev_name, u32 flags);
void dc_fsf_set_conf();

#endif