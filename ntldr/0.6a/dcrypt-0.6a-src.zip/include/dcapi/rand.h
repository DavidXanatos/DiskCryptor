#ifndef _RAND_
#define _RAND_

#include "dcapi.h"

int  dc_api rnd_init();
void dc_api rnd_reseed_now();

#endif