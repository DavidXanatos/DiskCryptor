#ifndef _BOOT_MENU_
#define _BOOT_MENU_

int boot_menu(int argc, wchar_t *argv[]);

#endif