#ifndef _TESTS_
#define _TESTS_

#include "cryptodef.h"

#ifdef CRYPT_TESTS
 int crypto_self_test();
#endif

#endif