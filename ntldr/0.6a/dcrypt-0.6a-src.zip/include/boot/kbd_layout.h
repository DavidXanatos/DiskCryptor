#ifndef _KBD_LAYOUT_
#define _KBD_LAYOUT_

s8 to_qwertz(s8 c);
s8 to_azerty(s8 c) ;

#endif