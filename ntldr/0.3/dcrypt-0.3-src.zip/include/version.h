#ifndef _VERSION_
#define _VERSION_

#define DC_MAJOR_VER   0
#define DC_MINOR_VER   3
#define DC_DRIVER_VER  235  /* driver version */
#define DC_BOOT_VER    44   /* bootloader version */
#define DC_FILE_VER    L"0.3.235.44"
#define DC_PRODUCT_VER L"0.3"

#endif
