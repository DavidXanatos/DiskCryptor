#ifndef _GF128_MUL_
#define _GF128_MUL_

void gf128_mul64(u8 *gf_a, u8 *gf_b, u8 *gf_p);

#endif