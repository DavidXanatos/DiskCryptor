#ifndef _CRC32_
#define _CRC32_

unsigned long crc32(unsigned char *dat, unsigned long len);
int crc32_test();

#endif
