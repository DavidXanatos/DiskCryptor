#ifndef _TESTS_
#define _TESTS_

int crypto_self_test();

#endif