#ifndef _KEYFILES_H_
#define _KEYFILES_H_

#include "volume.h"

int dc_api dc_add_keyfiles(dc_pass *pass, wchar_t *path);

#endif