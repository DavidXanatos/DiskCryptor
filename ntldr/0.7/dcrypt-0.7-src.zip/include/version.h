#ifndef _VERSION_
#define _VERSION_

#define DC_MAJOR_VER   0
#define DC_MINOR_VER   7
#define DC_DRIVER_VER  435  /* driver version */
#define DC_BOOT_VER    90   /* bootloader version */
#define DC_FILE_VER    "0.7.435.90"
#define DC_PRODUCT_VER "0.7"

#endif
