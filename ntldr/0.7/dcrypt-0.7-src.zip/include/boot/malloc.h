#ifndef _MALLOC_
#define _MALLOC_

void *malloc(int size);

#endif