#ifndef _DISK_NAME_H_
#define _DISK_NAME_H_

int dc_api dc_get_hw_name(int dsk_num, int is_cd, wchar_t *name, size_t max_name);

#endif