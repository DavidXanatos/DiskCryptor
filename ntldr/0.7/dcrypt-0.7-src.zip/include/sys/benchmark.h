#ifndef _BENCHMARK_
#define _BENCHMARK_

int dc_k_benchmark(crypt_info *crypt, dc_bench *info);

#endif