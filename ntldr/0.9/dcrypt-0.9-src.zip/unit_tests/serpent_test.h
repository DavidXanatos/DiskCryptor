#pragma once

int test_serpent256();