#pragma once

int test_aes256();