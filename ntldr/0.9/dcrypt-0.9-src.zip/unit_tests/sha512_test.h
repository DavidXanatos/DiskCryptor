#pragma once

int test_sha512();