#ifndef _VERSION_
#define _VERSION_

#define DC_MAJOR_VER   0
#define DC_MINOR_VER   9
#define DC_DRIVER_VER  593  /* driver version */
#define DC_BOOT_VER    106  /* bootloader version */
#define DC_FILE_VER    "0.9.593.106"
#define DC_PRODUCT_VER "0.9"

#endif
