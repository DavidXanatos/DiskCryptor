#ifndef _UIDRAW_
#define _UIDRAW_

int _draw_proc(
		int    message,
		LPARAM lparam
	);

#endif