#ifndef _BOOT_LOAD_H_
#define _BOOT_LOAD_H_

extern partition  p_parts[];
extern int        n_parts;
extern ldr_config conf;

#endif