#ifndef _VERSION_
#define _VERSION_

#define DC_MAJOR_VER   0
#define DC_MINOR_VER   4
#define DC_DRIVER_VER  292  /* driver version */
#define DC_BOOT_VER    69   /* bootloader version */
#define DC_FILE_VER    L"0.4.292.69"
#define DC_PRODUCT_VER L"0.4"

#endif
