﻿#pragma once

int test_xts_aes_only();