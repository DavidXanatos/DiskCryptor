﻿#pragma once

int test_twofish256();