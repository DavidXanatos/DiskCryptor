﻿#ifndef _CRC32_H_
#define _CRC32_H_

unsigned long _stdcall crc32(const unsigned char *p, unsigned long len);

#endif