#ifndef _PRCCOMMON_
#define _PRCCOMMON_

INT_PTR
CALLBACK
_tab_proc(
		HWND   hwnd,
		UINT   message,
		WPARAM wparam,
		LPARAM lparam
	);

#endif