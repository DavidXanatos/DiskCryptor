#ifndef _PRCPASS_
#define _PRCPASS_

int _dlg_get_pass(
		HWND	 hwnd,
		dlgpass	*pass
	);

int _dlg_change_pass(
		HWND	 hwnd,
		dlgpass	*pass
	);



#endif